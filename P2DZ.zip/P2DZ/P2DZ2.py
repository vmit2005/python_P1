num = int(input("ВВЕДИТЕ ЦЕЛОЕ ЧИСЛО :"))
if num == (num // 2) * 2:
    print("ЧИСЛО " + str(num) + " - ЧЕТНОЕ")
else:
    print("ЧИСЛО " + str(num) + " - НЕЧЕТНОЕ")
